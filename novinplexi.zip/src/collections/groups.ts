export const groups = {
    catalog: "محصولات",
    content: "گالری",
    customers: "مشتریان",
    customizations: "طراحی",
    orders: "سفارشات",
    posts: "مقالات",
    settings: "تنظیمات",
};
