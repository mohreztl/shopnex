export type IconProps = {
    color?: string;
    size?: number | string;
} & React.SVGAttributes<SVGElement>;
