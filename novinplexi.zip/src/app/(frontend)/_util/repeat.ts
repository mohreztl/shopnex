const repeat = (times: number) => {
    return Array.from(Array(times).keys());
};

export default repeat;
