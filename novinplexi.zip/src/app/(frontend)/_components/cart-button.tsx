import CartDropdown from "./cart-dropdown";

export default function CartButton() {
    return <CartDropdown />;
}
