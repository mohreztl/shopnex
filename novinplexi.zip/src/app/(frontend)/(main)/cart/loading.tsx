import SkeletonCartPage from "../../_templates/skeleton-cart-page";

export default function Loading() {
    return <SkeletonCartPage />;
}
