import SkeletonOrderConfirmed from "@/app/(frontend)/_components/skeleton-order-confirmed/skeleton-order-confirmed";

export default function Loading() {
    return <SkeletonOrderConfirmed />;
}
