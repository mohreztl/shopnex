export const listCartShippingMethods = (cartId: string) => {
    return [];
};

export const calculatePriceForShippingOption = (
    shippingOptionId: string,
    cartId: string
) => {
    return {};
};
