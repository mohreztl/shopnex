export const updateCustomer = (customer: any) => {
    return customer;
};

export const retrieveCustomer = () => {
    return {};
};
